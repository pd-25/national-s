<form action="">
    <section>
        <div class="container">
            <div class="row" style="margin-bottom:20px;justify-content: start;">
                <div class="col-4">
                    <p class="single-line" style="margin-bottom:0;margin-right:20px;">Form No.<strong class="full-line">250</strong></p>
                </div>
                <div class="col-4">
                    <p class="single-line" style="margin-bottom:0;">Student Name<strong class="full-line">02-03-2025</strong></p>
                </div>
            </div>
            <hr>
            <div class="row" style="margin-bottom:0px;margin-top:20px;justify-content: start;">
            <div class="span-3">
                <p class="single-line" style="margin-bottom:10px;margin-right:20px;">Form No.<strong class="full-line"></strong></p>
                <p class="single-line" style="margin-bottom:10px;">Date<strong class="full-line"></strong></p>
            </div>
            </div>
            <div class="row" style="margin-bottom:0px;">
            <div class="span-2">
                <img src="images/logo.png" class="img-fluid" style="margin-top:40px;">
            </div>
            <div class="span-2" style="text-align:right;">
                <img src="images/pro-pic.jpg" alt="Affix passport size photo of the pupil" class="img-fluid border-1" style="width:150px;height:195px;display: block;text-align: center;">
            </div>
            </div>
            <div class="row">
            <div class="span-12" style="padding-top:0px;">
                <h3 style="margin-top:0;"><b>Student's Profile</b></h3>
                <p class="single-line" style="margin-bottom:10px;">Name of Pupil(In Capital Letters):<strong class="full-line2" style="text-transform:uppercase;">Rsadasdasd Hasdd </strong></p>
                <p class="two-line" style="margin-bottom:10px;"><span>Admission sought for class:<strong class="line3" style="width:30%;">asda</strong></span> <span>Academic Year:<strong class="line3" style="width:30%;">asdsad</strong></span></p>
                <p class="two-line" style="margin-bottom:10px;"><span>Date of Birth:<strong class="line3" style="width:38%;">asda</strong></span> <span>Aadhar No:<strong class="line3" style="width:38%;">asdsad</strong></span></p>
                <p class="two-line" style="margin-bottom:10px;"><span>Nationality:<strong class="line3" style="width:38%;">asda</strong></span> <span>Religion<strong class="line3" style="width:42%;">asdsad</strong></span></p>
                <p class="two-line" style="margin-bottom:10px;"><span>Gender:<strong class="line3" style="width:45%;">asda</strong></span> <span>Caste<strong class="line3" style="width:40%;">asdsad</strong></span></p>
                <p class="single-line" style="margin-bottom:10px;">Residential Address:<strong class="full-line2" style="text-transform:uppercase;">Rsadasdasd Hasdd </strong></p>
                <p class="single-line" style="margin-bottom:10px;">&nbsp;<strong class="full-line2"></strong></p>
                <p class="two-line" style="margin-bottom:10px;"><span><strong class="line3" style="width:45%;"></strong></span> <span>Pin Code <strong class="line3" style="width:43%;">asdsad</strong></span></p>
                <p class="two-line" style="margin-bottom:10px;"><span>Mother Tongue:<strong class="line3" style="width:40%;">asda</strong></span> <span>Blood Group<strong class="line3" style="width:30%;">asdsad</strong></span></p>
                <h3 style="text-transform:none;font-size:16px;">Selection of Stream: ( Applicable for class Admissions in class XI)</h3>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                    <label class="form-check-label" for="inlineCheckbox1">Science</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                    <label class="form-check-label" for="inlineCheckbox2">Commerce</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                    <label class="form-check-label" for="inlineCheckbox3">Humanities</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                    <label class="form-check-label single-line" for="inlineCheckbox3">Combination<strong class="full-line2" style="width:100px;position: relative;display: inherit;padding: 0 60px 0 10px;">Rsadasdasd RsadasdasdRsadasdasd </strong></label>
                </div>
                <h3 style="text-transform:none;font-size:16px;">Previous Academic Information :</h3>
                <table class="mtb" style="margin-top:0px;width: 100%;">
                    <tbody>
                        <tr>
                        <th scope="col">Name of the previous school & location</th>
                        <th scope="col">Academic Session</th>
                        <th scope="col">Class</th>
                        <th scope="col">Second Language</th>
                        </tr>
                        <tr>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        </tr>
                        <tr>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                        </tr>
                    </tbody>
                </table>
                <h3 style="text-transform:none;font-size:16px;">Achievements of your child :</h3>
                <p>Please mention the achievements, if any, of your child in academics / co-curricular activities :</p>
                <p class="single-line" style="margin-bottom:10px;">&nbsp;<strong class="full-line2"></strong></p>
                <p class="single-line" style="margin-bottom:10px;">&nbsp;<strong class="full-line2"></strong></p>
                <p>Please mention, in brief, if there is any history of previous illness :</p>
                <p class="single-line" style="margin-bottom:10px;">&nbsp;<strong class="full-line2"></strong></p>
                <p class="single-line" style="margin-bottom:10px;">&nbsp;<strong class="full-line2"></strong></p>
            </div>
            </div>
        </div>
     </section>
</form>