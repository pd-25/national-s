<link rel="shortcut icon" type="image/png" href="{{asset('assets/website/images/favicon.png')}}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script> 
<script src="https://code.jquery.com/jquery-3.6.3.min.js"></script>
<!-- Bootstrap core CSS -->
<link href="{{asset('assets/website/css/bootstrap.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/website/css/bootstrap-grid.css')}}" rel="stylesheet">
<!-- Bootstrap core JavaScript -->
<script src="{{asset('assets/website/js/jquery-3.3.1.slim.min.js')}}"></script>
<script src="{{asset('assets/website/js/popper.min.js')}}"></script>
<script src="{{asset('assets/website/js/bootstrap.min.js')}}"></script>
<!-- Owl Carousel Assets pranab -->
<link href="{{asset('assets/website/owl-carousel/css/owl.carousel.min.css')}}" rel="stylesheet">
<link href="{{asset('assets/website/owl-carousel/css/owl.theme.default.min.css')}}" rel="stylesheet">
<!-- Owl Carousel Assets pranab -->
<!-- Custom styles for this template -->
<link href="{{asset('assets/website/css/modern-business.css')}}" rel="stylesheet">
<link href="{{asset('assets/website/css/style.css')}}" rel="stylesheet">
<link href="{{asset('assets/website/css/responsive.css')}}" rel="stylesheet">
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<!-- Menu -->
<link href="{{asset('assets/website/addons/jquery.smartmenus.bootstrap-4.css')}}" rel="stylesheet">
{{-- Ckeditor  --}}
<link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/44.2.1/ckeditor5.css" />
<script src="https://cdn.ckeditor.com/ckeditor5/44.2.1/ckeditor5.umd.js"></script>